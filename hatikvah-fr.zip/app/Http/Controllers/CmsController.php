<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Order;
Use App\User;

class CmsController extends MainController {
  
  public function dashboard(){
    //echo __METHOD__;
    
    // return view('cms.cms_master',self::$data);
    return view('cms.dashboard', self::$data);
  }
  
  public function orders(){
    //echo __METHOD__;
    //Order::getAll();
    self::$data['orders'] = Order::getAll();
    //dd(self::$data);
    return view('cms.orders', self::$data);
  }
    
  public function index(){
    echo __METHOD__;
  }
}
