<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\UserRequest;
use App\User;
use Session;

class UsercmsController extends MainController {

  public function index() {
    //echo __METHOD__;
    self::$data['users'] = User::all()->toArray();
    return view('cms.users', self::$data);
    
  }

  public function create() {
    self::$data['users_rules'] = User::all()->toArray();
    return view('cms.add_user', self::$data);
  }

  public function store(UserRequest $request) {
    User::saveNew($request);
    return redirect('cms/users');
  }

  public function show($id) {
    self::$data['item_id'] = $id;
    return view('cms.delete_user', self::$data);
  }

  public function edit($id) { 
    self::$data['item'] = User::find($id)->toArray();
    return view('cms.edit_user', self::$data);
    
  }

  public function update(Request $request, $id) {
    
  }

  public function destroy($id) {
    User::destroy($id);
    Session::flash('sm', 'Carousel has been deleted');
    return redirect('cms/carousels');  
    
  }

}
