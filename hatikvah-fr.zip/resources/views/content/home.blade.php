@extends('master')
@section('content')
<div class="row">
  <div class="col-md-12">
    <h3><i>B</i>-HCI | Home</h3>
  </div>
</div>
<br>
@include('inc.carousel')
@endsection