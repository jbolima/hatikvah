<div class="row">
  <div class="col-md-12">
    <nav class="navbar navbar-inverse navbar-fixed-top  navbar-custom">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><i>B</i>-HCI</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="<?php echo e(url('#about')); ?>"></a></li>
            <li><a href="<?php echo e(url('aboutus')); ?>">About Us</a></li>
            <li><a href="<?php echo e(url('contactus')); ?>">Contact Us</a></li>
            <!-- the dynamic link for navbar-->
            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><a href="<?php echo e(url($item['url'])); ?>"><?php echo e($item['link']); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <li><a href="<?php echo e(url('invest')); ?>">Investments</a></li>
            <!--li>
              <a href="<?php echo e(url('invest/checkout')); ?>">
                <div id="total-cart"><?php echo e(Cart::getTotalQuantity()); ?></div>
                <img width="20" src="<?php echo e(asset('images/shopping-cart.png')); ?>">
              </a>
            </li-->
          </ul>
          <ul class="nav navbar-nav navbar-right ">
            <?php if( ! Session::has('user_id')): ?>
              <li><a href="<?php echo e(url('user/signin')); ?>">Sign in</a></li>
              <li><a href="<?php echo e(url('user/signup')); ?>">Sign up</a></li>
            <?php else: ?>
              <li><a href="<?php echo e(url('user/profile')); ?>"><?php echo e(Session::get('user_name')); ?></a></li>
              <?php if(Session::has('is_admin')): ?>
                <li><a href="<?php echo e(url('cms/dashboard')); ?>">Admin Panel (CMS)</a></li>
              <?php endif; ?>
               <li><a href="<?php echo e(url('user/logout')); ?>">Logout</a></li>
            <?php endif; ?>
            <li>
              <a href="#"><img width="20" src="<?php echo e(asset('images/frenchflag.jpg')); ?>"> Français</a>
            </li>
            <li>
              <a href="#"><img width="20" src="<?php echo e(asset('images/englandflag.jpg')); ?>"> English</a>
            </li>
          </ul>

        </div>
      </div>
    </nav>
  </div>
</div><?php /**PATH C:\xampp\htdocs\hatikvah\resources\views/inc/nav.blade.php ENDPATH**/ ?>