<?php $__env->startSection('cms_content'); ?>
  <h2>Content link</h2>
  <div class="row">
    <div class="col-md-8">
      <p>
        <a class=" btn btn-success" href="<?php echo e(url('cms/content/create')); ?>">
          <span class="glyphicon glyphicon-plus"></span>
          Add new content
        </a>
      </p>
      <?php if($contents): ?>
        <br><br>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>Content title</th>
              <th>Updated at</th>
              <th><b>Operations</b></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($item['title']); ?></td>
                <td><?php echo e(date('d/m/Y', strtotime($item['updated_at']))); ?></td>
                <td>
                  <a href="<?php echo e(url('cms/content/' .$item['id'] .'/edit')); ?>">
                    <span class="glyphicon glyphicon-pencil text-success"></span>
                    Edit
                  </a> |
                  <a href="<?php echo e(url('cms/content/' .$item['id'])); ?>">
                    <span class=" text-succes glyphicon glyphicon-trash text-danger"></span>
                    Delete
                  </a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hatikvah\resources\views/cms/content.blade.php ENDPATH**/ ?>