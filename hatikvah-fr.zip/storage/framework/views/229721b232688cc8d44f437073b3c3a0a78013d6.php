<?php $__env->startSection('cms_content'); ?>
  <h2>Add new Menu link form</h2>
  <div class="row">
    <div class="col-md-8">
      <form action="<?php echo e(url('cms/menu')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
          <label for="link">Link</label>
          <input value="<?php echo e(old('link')); ?>" name="link" type="text" class="form-control origin-text" id="link" placeholder="Link">
        </div>
        <div class="form-group">
          <label for="url">Url</label>
          <input value="<?php echo e(old('url')); ?>" name="url" type="text" class="form-control target-text" id="url" placeholder="Url">
        </div>
        <div class="form-group">
          <label for="mtitle">Title</label>
          <input value="<?php echo e(old('mtitle')); ?>" name="mtitle" type="text" class="form-control" id="mtitle" placeholder="Title">
        </div>
        <input type="submit" name="submit" value="Save Menu" class="btn btn-secondary">
        <a class="btn btn-default" href="<?php echo e(url('cms/menu')); ?>">Cancel</a>
      </form>
      
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hatikvah\resources\views/cms/add_menu.blade.php ENDPATH**/ ?>