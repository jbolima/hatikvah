<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <?php if( $title != 'B-Hatikvah | '): ?>
      <h3><?php echo e($title); ?></h3>
    <?php endif; ?>
  </div>
</div>
<div class="row f-row">
  <?php if($products): ?>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-6">
        <h3><?php echo e($product->ptitle); ?></h3>
        <p><img  class="img-rounded" width="500" src="<?php echo e(asset('images/' .$product->pimage)); ?>"></p>
        <p class="text-justify" ><?php echo $product->particle; ?></p>
        <p><b>Price on site: </b>$<?php echo e($product->price); ?></p>
        <p>
          <?php if(! Cart::get($product->id)): ?>
            <input data-id="<?php echo e($product->id); ?>" type="button" value="+ Add to Cart" class="btn btn-success add-to-cart">
          <?php else: ?>
            <input disabled="disabled" data-id="<?php echo e($product->id); ?>" type="button" value="! In Cart" class="btn btn-success add-to-cart">
          <?php endif; ?>
          <a href="<?php echo e(url('invest/' .$product->curl .'/' .$product->purl)); ?>" class="btn btn-primary">View Investments Details</a>
        </p>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
    <div class="col-md-12">
      <p><i>No Investments for this request...</i></p>
    </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hatikvah\resources\views/content/products.blade.php ENDPATH**/ ?>