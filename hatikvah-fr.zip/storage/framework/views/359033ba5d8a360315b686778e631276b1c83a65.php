<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <h3><i>B</i>-Hatikvah Checkout</h3>
    <?php if($cart): ?>
      <table class="table table-bordered">
        <thead>
          <tr >
            <th class="text-center">Product</th>
            <th class="text-center">Quantity</th>
            <th class="text-center">Price</th>
            <th class="text-center">Sub-total</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($item['name']); ?></td>
              <td class="text-center">
                <input class="update-cart-item" data-id="<?php echo e($item['id']); ?>" data-op="minus" type="button" value="-">
                <input class="text-center" size = "1" type="text" value="<?php echo e($item['quantity']); ?>">
                <input class="update-cart-item" data-id="<?php echo e($item['id']); ?>" data-op="plus" type="button" value="+">
              </td>
              <td class="text-right">$<?php echo e($item['price']); ?></td>
              <td class="text-right">$<?php echo e($item['quantity'] * $item['price']); ?></td>
              <td class="text-center">
                <a href="<?php echo e(url('invest/remove-item?id=' .$item['id'])); ?>" class="text-danger"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>
              </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <p>
        <b>Total in Cart: </b> $<?php echo e(Cart::getTotal()); ?>

        <span class="pull-right">
          <a href="<?php echo e(url('invest/clear-cart')); ?>" class="btn btn-default">Clear cart</a>
        </span>
      </p>
      <p>
        <a href="<?php echo e(url('invest/order')); ?>" class="btn btn-primary">ORDER NOW!</a>
      </p>
    <?php else: ?>
      <p><i>No investment in the Cart...</i></p>
    <?php endif; ?>
    
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hatikvah\resources\views/content/checkout.blade.php ENDPATH**/ ?>