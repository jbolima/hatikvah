<?php $__env->startSection('cms_content'); ?>
  <h2>Edit product form</h2>
  <div class="row">
    <div class="col-md-8">
     <form action="<?php echo e(url('cms/products/'. $item['id'])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('PUT')); ?>

        <input type="hidden" name="item_id" value="<?php echo e($item['id']); ?>"> <!-- for unique from edit_category-->
        <div class="form-group">
          <label for="categorie-id">Category</label>
          <select class="form-control" name="categorie_id" id="categorie-id">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option <?php if($row['id'] == $item['categorie_id']): ?> selected="selected" <?php endif; ?> value="<?php echo e($row['id']); ?>"><?php echo e($row['ctitle']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        
        <div class="form-group">
          <label for="ptitle">Title</label>
          <input value="<?php echo e($item['ptitle']); ?>" name="ptitle" type="text" class="form-control origin-text" id="ptitle" placeholder="Title">
        </div>
        <div class="form-group">
          <label for="purl">Url</label>
          <input value="<?php echo e($item['purl']); ?>" name="purl" type="text" class="form-control target-text" id="purl" placeholder="Url">
        </div>
        <div class="form-group">
          <label for="particle">Article</label>
          <textarea class="form-control" name="particle" id="article"><?php echo e($item['particle']); ?></textarea>
        </div>
        <div class="form-group">
          <label for="price">Price</label>
          <input value="<?php echo e($item['price']); ?>" name="price" type="text" class="form-control" id="price" placeholder="Price">
        </div>
        <div class="form-group">
          <img width="70" src="<?php echo e(asset('images/' . $item['pimage'])); ?>">
          <br><br>
          <label for="pimage">Change product image</label>
          <input type="file" name="pimage" id="pimage">
        </div>
        <input type="submit" name="submit" value="Update product" class="btn btn-secondary">
        <a class="btn btn-default" href="<?php echo e(url('cms/products')); ?>">Cancel</a>
      </form>
      
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hatikvah\resources\views/cms/edit_product.blade.php ENDPATH**/ ?>