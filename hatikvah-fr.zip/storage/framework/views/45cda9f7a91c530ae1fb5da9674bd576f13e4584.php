<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <h3><i>B</i>-HCI | Home</h3>
  </div>
</div>
<br>
<?php echo $__env->make('inc.carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hatikvah\resources\views/content/home.blade.php ENDPATH**/ ?>