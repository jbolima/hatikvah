<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <h3>Sign Up</h3>
    <p>Here you can create your new account</p>
  </div>
</div>
<div class="row">
  <div class="col-md-6">
    <form action="" method="POST" novalidate="novalidate">
      <?php echo csrf_field(); ?><!--<input type="hidden" name="_token" value="IRXAXHLv5uzv8v1bmSmHmm6mU9lQx7mVy0se97JQ">-->
      
      <div class="form-group">
        <label for="name">Name</label>
        <input value="<?php echo e(old('name')); ?>" name="name" type="text" class="form-control" id="name" placeholder="Name">
        <span  class="text-danger"><?php echo e($errors->first('name')); ?></span> 
      </div>
      
      <div class="form-group">
        <label for="email">Email address</label>
        <input value="<?php echo e(old('email')); ?>" name="email" type="email" class="form-control" id="email" placeholder="Email">
        <span  class="text-danger"><?php echo e($errors->first('email')); ?></span>
      </div>
      
      <div class="form-group">
        <label for="password">Password</label>
        <input name="password" type="password" class="form-control" id="password" placeholder="Password">
        <span  class="text-danger"><?php echo e($errors->first('password')); ?></span>
      </div>
      
      <div class="form-group">
        <label for="confirm-password">Confirm Password</label>
        <input name="password_confirmation" type="password" class="form-control" id="confirm-password" placeholder="Confirm Password">
        <!--span  class="text-danger"><?php echo e($errors->first('password')); ?></span-->
      </div>
      
      <input class="btn btn-success" type="submit" name="submit" value="Signup">
     
      </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hatikvah\resources\views/forms/signup.blade.php ENDPATH**/ ?>