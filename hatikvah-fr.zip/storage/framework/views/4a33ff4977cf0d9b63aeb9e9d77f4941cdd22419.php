<!DOCTYPE html>
<html>
  <head>
    <title><?php if(!empty($title)): ?> <?php echo e($title); ?> <?php endif; ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display+SC&display=swap" rel="stylesheet">
    
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css"/>
    <script>var BASE_URL = "<?php echo e(url('')); ?>/";</script>
  </head>
  <body>
    <header>
      <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><!-- call nav.blade.php from inc -->
    </header>
    <br><br>
    <main>
      <div class="container">
        <div class="col-md-12">
          <h2 class="text-center"><i>B</i>-Hatikvah Consulting & Investments</h2>
        </div>
        <?php echo $__env->make('inc.sm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- call sm alert from the folder views/inc -->
        <!--Errors validations on top of the signin page
        <?php if($errors->any()): ?>
          <div class="row">
            <div class="col-md-12">
              <div class="alert alert-danger">
                <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
            </div>
          </div>
         <?php endif; ?>
        End of Errors validation -->
        <?php echo $__env->yieldContent('content'); ?>
      </div>
    </main>
    <hr>
    <footer>
      <div class="container">
        <div class="col-md-12">
          <p class="text-center paragraph"><b><i>B</i>-HCI</b> ** B-Hatikvah Consulting & Investiments &copy 2019 - <?php echo e(date('Y')); ?> Designed by JMBA</p>
        
        </div>
      </div>
    </footer>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.js"></script>
    <script src="<?php echo e(asset('js/script.js')); ?>" type="text/javascript"></script>
  </body>
</html>

<?php /**PATH C:\xampp\htdocs\hatikvah\resources\views/master.blade.php ENDPATH**/ ?>