<?php $__env->startSection('cms_content'); ?>
  <h2>Carousels Details</h2>
  <div class="row">
    <div class="col-md-12">
      <p>
        <a class=" btn btn-success" href="<?php echo e(url('cms/carousels/create')); ?>">
          <span class="glyphicon glyphicon-plus"></span>
          Add New Carousel
        </a>
      </p>
      <?php if($carousels): ?>
        <br><br>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>Caousels</th>
              <th>Images</th>
              <th>Created at</th>
              <th>Updated at</th>
              <th><b>Operations</b></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $carousels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($item['stitle']); ?></td>
                <td><img width="50" src="<?php echo e(asset('images/'. $item['simage'])); ?>"></td>
                <td><?php echo e(date('d/m/Y', strtotime($item['created_at']))); ?></td>
                <td><?php echo e(date('d/m/Y', strtotime($item['updated_at']))); ?></td>
                <td>
                  <a href="<?php echo e(url('cms/carousels/' .$item['id'] .'/edit')); ?>">
                    <span class="glyphicon glyphicon-pencil text-success"></span>
                    Edit
                  </a> |
                  <a href="<?php echo e(url('cms/carousels/' .$item['id'])); ?>">
                    <span class=" text-succes glyphicon glyphicon-trash text-danger"></span>
                    Delete
                  </a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hatikvah\resources\views/cms/carousels.blade.php ENDPATH**/ ?>