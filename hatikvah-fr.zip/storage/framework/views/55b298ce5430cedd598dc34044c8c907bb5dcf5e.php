<?php $__env->startSection('cms_content'); ?>
  <h2>Edit Menu link form</h2>
  <div class="row">
    <div class="col-md-8">
      <form action="<?php echo e(url('cms/menu/'. $item['id'])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('PUT')); ?>

        <input type="hidden" name="item_id" value="<?php echo e($item['id']); ?>">
        <div class="form-group">
          <label for="link">Link</label>
          <input value="<?php echo e($item['link']); ?>" name="link" type="text" class="form-control origin-text" id="link" placeholder="Link">
        </div>
        <div class="form-group">
          <label for="url">Url</label>
          <input value="<?php echo e($item['url']); ?>" name="url" type="text" class="form-control target-text" id="url" placeholder="Url">
        </div>
        <div class="form-group">
          <label for="mtitle">Title</label>
          <input value="<?php echo e($item['mtitle']); ?>" name="mtitle" type="text" class="form-control" id="mtitle" placeholder="Title">
        </div>
        <input type="submit" name="submit" value="Update Menu" class="btn btn-secondary">
        <a class="btn btn-default" href="<?php echo e(url('cms/menu')); ?>">Cancel</a>
      </form>
      
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hatikvah\resources\views/cms/edit_menu.blade.php ENDPATH**/ ?>