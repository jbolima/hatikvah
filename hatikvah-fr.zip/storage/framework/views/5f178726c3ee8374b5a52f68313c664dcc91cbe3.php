<?php $menu = App\Menu::all()->toArray(); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-12">
      <h1>OOPS! Your request not found</h1>
      <p><a href="<?php echo e(url('')); ?>">Back to home page</a></p>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hatikvah\resources\views/errors/404.blade.php ENDPATH**/ ?>