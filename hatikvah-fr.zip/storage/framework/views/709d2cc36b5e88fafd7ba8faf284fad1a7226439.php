<?php $__env->startSection('cms_content'); ?>
  <h2>Delete Category</h2>
  <div class="row">
    <div class="col-md-8">
      <form action="<?php echo e(url('cms/categories/' .$item_id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <!-- http protocol for deleting 
        <input type="hidden" name="_method" value="DELETE">
        <!--end http protocol for delete-->
        <!-- Laravel elete method-->
        <?php echo e(method_field('DELETE')); ?>

        <h3>Are you sure you want to delete this category?</h3>
        <input type="submit" name="submit" value="Delete" class="btn btn-danger">
        <a class="btn btn-default" href="<?php echo e(url('cms/categories')); ?>">Cancel</a>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hatikvah\resources\views/cms/delete_category.blade.php ENDPATH**/ ?>