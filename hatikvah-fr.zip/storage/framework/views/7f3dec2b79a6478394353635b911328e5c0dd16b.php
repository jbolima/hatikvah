<?php $__env->startSection('cms_content'); ?>
  <h2>Users Oders </h2>
  <div class="row">
    <div class="col-md-12">
      <?php if(!$orders->isEmpty() ): ?>
        <br><br>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>User</th>
              <th>Total</th>
              <th>Order details</th>
              <th>Order date</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($item->name); ?></td>
                <td>$<?php echo e($item->total); ?></td>
                <td>
                  <ul>
                    <?php $__currentLoopData = unserialize($item->data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($row['name']); ?>, Price: $<?php echo e($row['price']); ?>, Quantity: <?php echo e($row['quantity']); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </td>
                <td><?php echo e(date('d/m/Y', strtotime($item->created_at))); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hatikvah\resources\views/cms/orders.blade.php ENDPATH**/ ?>