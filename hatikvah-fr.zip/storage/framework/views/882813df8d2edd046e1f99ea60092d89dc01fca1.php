<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <h3>B-HCI | Investments</h3>
  </div>
</div>
<div class="row f-row">
  <?php if($categories): ?>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4 col-sm-6">
        <h3><?php echo $category['ctitle']; ?></h3>
        <p><img width="350" src="<?php echo e(asset('images/' .$category['cimage'])); ?>" class="img-rounded"></p>
        <p class="text-justify"><?php echo $category['carticle']; ?></p>
        <p><a href="<?php echo e(url('invest/' .$category['curl'])); ?>" class="btn btn-success">View Investments</a></p>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
    <div class="col-md-12">
      <p><i>No Investments available...</i></p>
    </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hatikvah\resources\views/content/categories.blade.php ENDPATH**/ ?>