<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <?php if($product): ?>
      <h3><?php echo e($product->ptitle); ?></h3>
      <p><img  class="img-rounded" width="500" src="<?php echo e(asset('images/' .$product->pimage)); ?>"></p>
      <p class="text-justify" ><?php echo $product->particle; ?></p>
      <p><b>Price on site: </b>$<?php echo e($product->price); ?></p>
      <p>
        <?php if(! Cart::get($product->id)): ?>
          <input data-id="<?php echo e($product->id); ?>" type="button" value="+ Add to Cart" class="btn btn-success add-to-cart">
        <?php else: ?>
          <input disabled="disabled" data-id="<?php echo e($product->id); ?>" type="button" value="! In Cart" class="btn btn-success add-to-cart">
        <?php endif; ?>
        <a href="<?php echo e(url('invest/checkout')); ?>" class="btn btn-primary">Check out</a>
      </p>
    <?php else: ?>
      <p><i>No details for this investments request....</i></p>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hatikvah\resources\views/content/item.blade.php ENDPATH**/ ?>